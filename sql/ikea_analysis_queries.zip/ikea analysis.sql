SELECT * FROM ikea_analysis.ikea_products;

SELECT count(*) FROM ikea_analysis.ikea_products;

SELECT COUNT(DISTINCT unique_id) FROM ikea_products;

SELECT DISTINCT badge FROM ikea_products;

SELECT price_tier FROM ikea_products;

#Basic Analysis
SELECT 
	main_category,
    COUNT(*) AS total_products,
    SUM(price_tier = 'Premium') AS premium_count,
    ROUND(SUM(price_tier = 'Premium') / COUNT(*) * 100, 2) AS premium_ratio
FROM ikea_products
GROUP BY main_category
ORDER BY premium_ratio DESC;

SELECT 
	main_category,
    ROUND(AVG(product_rating_count), 2) AS avg_engagement
FROM ikea_products
GROUP BY main_category
ORDER BY avg_engagement DESC;

SELECT 
	country,
    ROUND(SUM(price_tier = 'Premium') / COUNT(*) * 100, 2) AS premium_ratio
FROM ikea_products
GROUP BY country
ORDER BY premium_ratio DESC;

SELECT 
	price_tier,
    ROUND(AVG(product_rating_count),2) AS avg_engagement
FROM ikea_products
GROUP BY price_tier
ORDER BY avg_engagement DESC;

SELECT 
	main_category,
    ROUND(SUM(price_tier = 'Premium') / COUNT(*) * 100, 2) AS premium_ratio,
    RANK() OVER (
		ORDER BY ROUND(SUM(price_tier = 'Premium') / COUNT(*) * 100, 2) DESC
	) AS premium_rank
FROM ikea_products
GROUP BY main_category
lIMIT 5;

SELECT * FROM (
	SELECT
		country,
        product_name,
        price_inr,
        RANK() OVER (
			PARTITION BY country
            ORDER BY price_inr DESC
		) AS price_rank
	FROM ikea_products
    WHERE price_tier = 'Premium'
) ranked
WHERE price_rank <= 3;

SELECT 
    price_tier,
    ROUND(SUM(has_reviews)/COUNT(*) * 100, 2) AS review_percent
FROM ikea_products
GROUP BY price_tier
ORDER BY review_percent DESC;

# Strategic Analyst

#produuct with high price and high engagement (as elite performers).
SELECT
	product_name,
    main_category,
    country,
    price_inr,
    product_rating_count
FROM ikea_products
WHERE price_tier = 'Premmium'
AND product_rating_count > (
	SELECT AVG(product_rating_count)
	FROM ikea_products
)
ORDER BY product_rating_count DESC
LIMIT 20
#Output is none, no product is elite performers.

#undervalued products (cheap but high rating).
SELECT
	product_name,
    main_category,
    country,
    price_inr,
    product_rating,
    product_rating_count
FROM ikea_products
WHERE price_tier = 'Budget'
AND product_rating > (
	SELECT AVG(product_rating)
	FROM ikea_products
)
AND product_rating_count > 50
ORDER BY product_rating DESC
LIMIT 20;

#Engagement Gap by tier
SELECT 
    price_tier,
    ROUND(AVG(product_rating_count),2) AS avg_engagement,
    ROUND(STDDEV(product_rating_count),2) AS engagement_variability
FROM ikea_products
GROUP BY price_tier;

#category engagement density
SELECT 
    main_category,
    ROUND(SUM(product_rating_count) / COUNT(*),2) AS engagement_density
FROM ikea_products
GROUP BY main_category
ORDER BY engagement_density DESC
LIMIT 10;

SELECT 
    country,
    main_category,
    ROUND(SUM(price_tier='Premium') / COUNT(*) * 100,2) AS premium_ratio
FROM ikea_products
GROUP BY country, main_category
ORDER BY premium_ratio DESC
LIMIT 20;

SELECT 
    product_name,
    main_category,
    country,
    price_inr,
    price_tier,
    product_rating,
    product_rating_count
FROM ikea_products
WHERE product_rating >= 4.5
AND product_rating_count > 100
ORDER BY product_rating_count DESC
LIMIT 20;