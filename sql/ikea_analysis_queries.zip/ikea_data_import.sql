CREATE DATABASE ikea_analysis;
USE ikea_analysis;

DROP TABLE ikea_products;
 
SHOW VARIABLEs LIKE 'local_infile';
 
SET GLOBAL local_infile = 1;
 
CREATE TABLE ikea_products (
    unique_id TEXT,
    product_id TEXT,
    product_name TEXT,
    product_type TEXT,
    product_measurements TEXT,
    product_description TEXT,
    main_category TEXT,
    sub_category TEXT,
    product_rating TEXT,
    product_rating_count TEXT,
    badge TEXT,
    online_sellable TEXT,
    url TEXT,
    price TEXT,
    currency TEXT,
    discount TEXT,
    sale_tag TEXT,
    country TEXT,
    price_inr TEXT,
    discounted_price_inr TEXT,
    `Active Participation` TEXT,
    has_reviews TEXT,
    price_tier TEXT,
    discount_level TEXT,
    engagement_level TEXT,
    has_badge TEXT
);


LOAD DATA LOCAL INFILE "C:/Users/Tarush Tarang/Downloads/IKEA price analysis/ikea_feature_engineered.csv"
INTO TABLE ikea_products
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

SELECT COUNT(*) FROM ikea_products;

